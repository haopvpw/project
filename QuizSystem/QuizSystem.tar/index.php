<!DOCTYPE html>
<html>
<?php include_once('include/header.php');?>
<body>
<div class="wrapper">
<div class="container">
<?php include_once('include/header1.php');?>
<!--menu-->
<?php include_once('include/menu.php');?>
<!-- slideshow -->
<?php include_once('include/slider.php');?>
<!--footer-->
<?php include_once('include/footer.php');?>
</div>
</div>
</body>
</html>

