<div class="menu">
<ul>
<li><a href="index.php">Home</a></li>
<li><a href="register.php">Student Register</a></li>
<li><a href="teacherRegister.php">Lecturer Register</a></li>
<li><a href="Teacher/index.php">Lecturer Login</a></li>
<!--<li><a href="admin/index.php">Admin Login</a></li>-->
<li><a href="exam.php">Take Exam</a></li>
</ul>
</div>
