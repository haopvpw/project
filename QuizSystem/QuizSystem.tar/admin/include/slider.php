<div class="slider">
<div id="slideshow">

	<ul class="slides">
    	<li><img src="img/photos/1.jpg" width="794" height="320" alt="picture1" /></li>
        <li><img src="img/photos/2.jpg" width="794" height="320" alt="picture2" /></li>
        <li><img src="img/photos/3.jpg" width="794" height="320" alt="picture3" /></li>
     </ul>

    <span class="arrow previous"></span>
    <span class="arrow next"></span>
</div>

</div>