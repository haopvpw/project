<div class="footer">
<p>By Anri Morchiladze and Shota Lejhava</p>
<div>
