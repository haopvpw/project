<?php include_once('include/header.php');?>
<body>
<div class="wrapper">
<div class="container">
<?php include_once('include/header1.php');?>
<!-- menu  -->
<?php include_once('include/menu.php');?>
<div class="thank-msg">
 <p>Your Registration is done Successfully Thank you!</p>
 </div>
<!-- footer  -->
<?php include_once('include/footer.php');?>
</div>
</div>
</body>
</html>