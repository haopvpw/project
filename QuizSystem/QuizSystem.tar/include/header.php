<!DOCTYPE html>
<html lang="eng">
<head>
<title>Online Examination Software</title>
<meta charset="utf-8"/>
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script src="js/script.js"></script>
<script src="js/autoadvance.js"></script>
<link rel="stylesheet" type="text/css" href="css/styles.css" />
</head>
</html>

